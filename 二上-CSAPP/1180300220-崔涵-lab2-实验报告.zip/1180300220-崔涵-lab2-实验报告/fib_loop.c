#include <stdio.h>
#define MAX 0xFF

int main(){
    printf("int = %u\n",sizeof(int));
    int a[MAX];
    a[0] = 0;
    printf("int[0] = %d\n",a[0]);
    a[1] = 1;
    printf("int[1] = %d\n",a[1]);
    for(int i= 2;i <= 50;i++){
        a[i] = a[i-1] + a[i-2];
        printf("int[%d] = %d\n",i,a[i]);
    }
    // int : 47
    printf("-------------------\n");
    printf("long = %u\n",sizeof(long));
    long f[MAX];
    f[0] = 0;
    f[1] = 1;
    printf("long[0] = %ld\nlong[1] = %ld\n",f[0],f[1]);
    for(int i = 2;i <= 95;i++){
        f[i] = f[i-1] + f[i-2];
        printf("long[%d] = %ld\n",i,f[i]);
    }
    // long int : 93
    printf("-------------------\n");

    unsigned int ui[MAX];
    ui[0] = 0;
    ui[1] = 1;
    printf("ui[0] = %u\nui[1] = %u\n",ui[0],ui[1]);
    for(int i = 2;i <= 50;i++){
        ui[i] = ui[i-1] + ui[i-2];
        printf("ui[%d] = %u\n",i,ui[i]);
    }
    //unsigned int :47
    printf("-------------------\n");

    unsigned long ul[MAX];
    ul[0] = 0;
    ul[1] = 1;
    printf("ul[0] = %lu\nul[1] = %lu\n",ul[0],ul[1]);
    for(int i = 2;i <= MAX;i++){
        ul[i] = ul[i-1] + ul[i-2];
        printf("ul[%d] = %lu\n",i,ul[i]);
    }
    //unsigned long : 93
    printf("-------------------\n");


    return 0;
}