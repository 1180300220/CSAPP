#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int a;
char s[20];
void i_to_a(int x){
    int flag = 0;
    int temp = x;
    int i = 0;
    if(temp < 0){
        flag = 1;
        temp = -temp;
    }
    for(;temp > 0;i++){
        s[i] = temp % 10 + '0';
        // printf("i = %d,tmp 10 = %d\n",i,temp%10);
        temp = (temp - temp % 10) / 10;
        // printf("temp = %d\n",temp);
    }
    if(flag == 1)   s[i] = '-';
    for(int j = i;j >= 0;j--){
        printf("s[%d] = %c\n",(i)-j,s[j]);
    }

}

int main(){
    scanf("%d",&a);
    i_to_a(a);
    return 0;
}