#include <stdio.h>

int main(){

    float c = 1.0;
    float d = c/0;
    printf("result = %lf\n",d);

    return 0;

}