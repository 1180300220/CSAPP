#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int flag = 1;
char s[100000];
int f[100000];

float a_to_f(char *x){
    int i = 0;
    double result = 0.0;
    if(s[0] == '-'){
        flag = 1;
        s[0] = 0;
    }
    for(i = 0;i <= strlen(x)-1;i++){
        if(s[i] != '.'){
            f[i] = s[i] - '0';
            result = result * 10 + f[i];
            // printf("i = %d,result = %f\n",i,result);
        }else{
            break;
        }
    }
    i++;
    float ex = 10.0;
    for(;i <= strlen(x)-1;i++){
        f[i] = s[i] - '0';
        result = result + f[i]/ex;
        // printf("f[%d]/ex = %f\n",i,f[i]/ex);
        // printf("i = %d,result = %f\n",i,result);
        ex = ex * 10.0;
    }
    return result;
}
int main(){
    gets(s);
    printf("result = %f\n",a_to_f(s));

    return 0;
}