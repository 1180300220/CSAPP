#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 0xFF;
int flag = 0;
char s[1000000];
int f[1000000];
int atoi(){
    if(s[0] == '-'){
        flag = 1;
        s[0] = '0';
    }
    int len = strlen(s);
    // printf("len = %d\n",len);
    int result = 0;
    for(int i = 0;i < len;i++){
        f[i] = s[i] - '0';
        // printf("f[%d] = %d\n",i,f[i] );
    }
    
    for(int i = 0;i < len;i++){
        result = result *10 + f[i];
        // printf("result = %d\n",result);
    }
    if(flag == 1){
        result = -result;
    }
    return result;

}
int main(){
    gets(s);
    printf("result = %d\n",atoi(s));

    return 0;
}