#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int flag = 0;
float x;
char s[100];
void f_to_a(float a){
    int i = 0;
    int j1 = 0;
    float ex = 0.1;
    int tmp1 = a;
    float tmp2;

    // if_negative
    if(tmp1 < 0){
        flag = 1;
        tmp1 = -tmp1;
        tmp2 = -(a + tmp1);
    }else
    {
        tmp2 = a - tmp1;
    }
    

    //Integral part
    for(;tmp1 > 0;i++){
        s[i] = tmp1 % 10 + '0';
        tmp1 = (tmp1 - tmp1 % 10)/10;
        // printf("tmp1 = %d\n",tmp1);
        // printf("s[%d] = %c\n",i,s[i]);
    }
    //Minus sign
    if(flag == 1){
        s[i++] = '-';
    }
    j1 = i;
    printf("j1 = %d\n",j1);
    
    //dot
    s[i++] = '.';

    //decimal part
    for(int j = 0;j <= 5;j++){
        int result = tmp2 / ex;
        printf("result = %d\n",result);
        s[i++] = result + '0';
        tmp2 = (tmp2 -result * 0.1) * 10;
        printf("tmp2 = %f\n",tmp2);
    }

    // output
    for(int j = j1-1;j >= 0;j--){
        printf("s[%d] = %c\n",j1-j,s[j]);
    }
    for(int j = j1;j <= j1 + 5;j++){
        printf("s[%d] = %c\n",j,s[j]);
    }
    

}

int main(){
    scanf("%f",&x);
    f_to_a(x);

    return 0;
}