#include <stdio.h>
#include <float.h>

typedef unsigned char *byte_pointer;

void show_pos_zero(byte_pointer start){
    start[0] = 0x00;
    printf("%.2x\t",start[0]);
    start[1] = 0x00;
    printf("%.2x\t",start[1]);
    start[2] = 0x00;
    printf("%.2x\t",start[2]);
    start[3] = 0x00;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_neg_zero(byte_pointer start){
    start[0] = 0x00;
    printf("%.2x\t",start[0]);
    start[1] = 0x00;
    printf("%.2x\t",start[1]);
    start[2] = 0x00;
    printf("%.2x\t",start[2]);
    start[3] = 0x80;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_min(byte_pointer start){
    start[0] = 0x01;
    printf("%.2x\t",start[0]);
    start[1] = 0x00;
    printf("%.2x\t",start[1]);
    start[2] = 0x00;
    printf("%.2x\t",start[2]);
    start[3] = 0x00;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_max(byte_pointer start){
    start[0] = 0xff;
    printf("%.2x\t",start[0]);
    start[1] = 0xff;
    printf("%.2x\t",start[1]);
    start[2] = 0x7f;
    printf("%.2x\t",start[2]);
    start[3] = 0x7f;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_min_std(byte_pointer start){
    start[0] = 0x00;
    printf("%.2x\t",start[0]);
    start[1] = 0x00;
    printf("%.2x\t",start[1]);
    start[2] = 0x80;
    printf("%.2x\t",start[2]);
    start[3] = 0x00;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_pos_inf(byte_pointer start){
    start[0] = 0x00;
    printf("%.2x\t",start[0]);
    start[1] = 0x00;
    printf("%.2x\t",start[1]);
    start[2] = 0x80;
    printf("%.2x\t",start[2]);
    start[3] = 0x7f;
    printf("%.2x\t",start[3]);
    printf("\n");
}
void show_nan(byte_pointer start){
    start[0] = 0xff;
    printf("%.2x\t",start[0]);
    start[1] = 0xff;
    printf("%.2x\t",start[1]);
    start[2] = 0xff;
    printf("%.2x\t",start[2]);
    start[3] = 0x7f;
    printf("%.2x\t",start[3]);
    printf("\n");
}


int main(){
/*    float zero1 = 0x0000 0000 0000 0000 0000 0000 0000 0000;
    float zero2 = 0x10000000000000000000000000000000;
    float pos_min = 0x0000000000000000000000000000001;
    float pos_max = 0x 0111 1111 0111 1111 1111 1111 1111 1111;
    float pos_min_strd = 0x 0000 0000 1000 0000 0000 0000 0000 0000;
    float pos_inf = 0x 0111 1111  1000 0000  0000 0000  0000 0000;
    float Nan = 0x 0111 1111 1111 1111 1111 1111 1111 1111; 
    */
   float zero1;
   show_pos_zero((byte_pointer)&zero1);
   printf("positive_zero = %f\n",zero1);
   float zero2;
   show_neg_zero((byte_pointer)&zero2);
   printf("negative_zero = %f\n",zero2);
   float min;
   show_min((byte_pointer)&min);
   printf("min = %f\n",min);
   float max;
   show_max((byte_pointer)&max);
   printf("max = %f\n",max);
   float min_std;
   show_min_std((byte_pointer)&min_std);
   printf("min_std = %f\n",min_std);
   float inf;
   show_pos_inf((byte_pointer)&inf);
   printf("inf = %f\n",inf);
   float nan;
   show_nan((byte_pointer)&nan);
   printf("nan = %f\n",nan);

   return 0;


}