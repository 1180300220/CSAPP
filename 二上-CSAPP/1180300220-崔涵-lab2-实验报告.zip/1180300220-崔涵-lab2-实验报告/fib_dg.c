#include <stdio.h>
#define MAX 0xFF
int f[MAX];

int fib(int x){
    if(x == 0){
        f[0] = 0;
    }else if(x == 1){
        f[1] = 1;
    }else{
        if(f[x-1] == 0){
            f[x-1] = fib(x-1);
        }
        if(f[x-2] == 0){
            f[x-2] = fib(x-2);
        }
        f[x] = f[x-1] + f[x-2];
    }
    // printf("f[%d] = %d\n",x,f[x]);
//     fib(x) = fib(x-1) + fib(x-2);
    return f[x];	
}

int main(){
    for(int i = 0;i <= MAX;i++){
        f[i] = 0;
    }
    printf("fib starts\n");
    fib(50);
    printf("fib ends;\n");
    for(int i = 0;i <= 50;i++)
    {
        printf("f[%d] = %d\n",i,f[i]);
    }
    return 0;
}
