#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int utf8len(char *z){
    int byte_num;
    if(*z <= 0xFE000000 && *z >= 0xFC000000){
        byte_num = 6;
    }
    else if(*z >= 0xF8000000){
        byte_num = 5;
    }
    else if(*z >= 0xf0000000){
        byte_num = 4;
    }
    else if(*z >= 0xE0000000){
        byte_num = 3;
    }
    else if(*z >= 0xC0000000){
        byte_num = 2;
    }
    else if(*z <= 0x80000000){
        byte_num = 1;
    }
    printf("byte_Num = %d\n",byte_num);
    char* y = z;
    int len = 0;
    while(*y != '\0' && len < strlen(z)){
        len ++;
        y += byte_num;
    }
    return len;
}


int main(){
    char z[] = "崔涵";
    int a = utf8len(z);
    printf("a = %d\n",a);

    return 0;
}