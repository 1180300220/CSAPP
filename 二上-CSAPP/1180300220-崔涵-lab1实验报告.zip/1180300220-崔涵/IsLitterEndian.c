#include <stdio.h>

typedef unsigned char *byte_pointer;
void isLittleEndian(byte_pointer start,size_t len){
    size_t i;
    if(start[len] == 0){
        printf("小端序\n");
    }else{
        printf("大端序\n");
    }
}

int main(){
    int x = 3;
    isLittleEndian((byte_pointer) &x,sizeof(int));
    return 0;
}