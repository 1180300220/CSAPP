#include <stdio.h>

int stuId = 1;
short testShort = 2;
long testLong = 1234567890;
unsigned int stu = 1180300220;
char a = 'a';
unsigned char b = 'b';
char name[7] = "崔涵";
float Id = 220182200009300016;
double testDouble = 987654321;

typedef struct{
    int test1;
    int test2;
}testStruct;
typedef union{
    int test1;
    int test2;
}testUnion;
typedef enum{
    enum_1 = 1,enum_2,enum_3
}testEnum;




typedef unsigned char *byte_pointer;

void show_bytes(byte_pointer start,size_t len){
    size_t i;
    for(i = 0;i < len;i++){
        printf("%.2x  ",start[i]);
    }
}

int main(){
    printf("int\tstuId\t%d\t%p\t",stuId,&stuId);
    show_bytes((byte_pointer) &stuId, sizeof(int));
    printf("\n");

    printf("short\ttestShort\t%d\t%p\t",testShort,&testShort);
    show_bytes((byte_pointer) &testShort, sizeof(short));
    printf("\n");

    printf("long\ttestLong\t%ld\t%p\t",testLong,&testLong);
    show_bytes((byte_pointer) &testLong, sizeof(long));
    printf("\n");

    printf("unsigned_int\tstu\t%d\t%p\t",stu,&stu);
    show_bytes((byte_pointer) &stu,sizeof(unsigned int));
    printf("\n");
    
    printf("string\tname\t");
    for(int i = 1;i <= 7;i++){
        printf("%c",name[i]);
    }
    printf("\t%p--%p\t",name,name+7);
    for(int i = 0;i <= 7;i++){
        show_bytes((byte_pointer) name+i,sizeof(char));
    }
    printf("\n");

    printf("char\ta\t%c\t%p\t",a,&a);
    show_bytes((byte_pointer) &a,sizeof(char));
    printf("\n");

    printf("unsigned_char\tb\t%c\t%p\t",b,&b);
    show_bytes((byte_pointer) &b,sizeof(unsigned char));
    printf("\n");

    printf("float\tId\t");
    printf("%.0f\t",Id);
    printf("%p\t",&Id);
    show_bytes((byte_pointer) &Id,sizeof(float));
    printf("\n");

    printf("double\ttestDouble\t%lf\t%p\t",testDouble,&testDouble);
    show_bytes((byte_pointer) &testDouble,sizeof(double));
    printf("\n");

    testStruct Struct1;
    Struct1.test1 = 1;
    Struct1.test2 = 2;    
    printf("struct\tStruct1\tStruct1.test1=%d Struct1.test2=%d\t%p\t",Struct1.test1,Struct1.test2,Struct1);
    show_bytes((byte_pointer) &Struct1,sizeof(testStruct));
    printf("\n");

    testUnion Union1;
    Union1.test1 = 11;
    Union1.test2 = 22;
    printf("union\tUnion1\tUnion1.test1 = %d Union1.test2 = %d\t%p\t",Union1.test1,Union1.test2,Union1);
    printf("\n");

    testEnum Enum1;
    printf("enum\tEnum1\tenum_1 = %d enum_2 = %d enum_3 = %d\t%p\t",enum_1,enum_2,enum_3,Enum1);
    show_bytes((byte_pointer) &Enum1,sizeof(testEnum));
    printf("\n");


    return 0;
}