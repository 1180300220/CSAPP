#include <stdio.h>


int main(){
    int i = 999;
    int s = sizeof(int*);
    printf("the word size is %d\n",s * 8);
    return 0;
}